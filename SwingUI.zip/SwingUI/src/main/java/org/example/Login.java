package org.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame{

    private JPanel MainPanel;
    private JTextField UsuarioTxt;
    private JPasswordField PasswordTxt;
    private JLabel UsuarioLbl;
    private JLabel PasswordLbl;
    private JButton LoginBtn;
    private JButton LimpiarBtn;
    private JCheckBox DesactivarChk;

    public Login(){

        setContentPane(MainPanel);
        setTitle("Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(200,200);
        setVisible(true);

        LoginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = UsuarioTxt.getText();
                String pass = PasswordTxt.getText();

                if(user.equals("jcenteno")&&pass.equals("1234")){
                    JOptionPane.showMessageDialog(null,"Ingreso correctamente");
                    limpiar();
                } else {
                    JOptionPane.showMessageDialog(null, "Verifique sus credenciales");
                }
            }
        });

        LimpiarBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiar();
            }
        });

        DesactivarChk.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(DesactivarChk.isSelected()){
                    UsuarioTxt.setEnabled(false);
                    PasswordTxt.setEnabled(false);
                    LoginBtn.setEnabled(false);
                } else {
                    UsuarioTxt.setEnabled(true);
                    PasswordTxt.setEnabled(true);
                    LoginBtn.setEnabled(true);
                }
            }
        });

    }

    public void limpiar(){
        UsuarioTxt.setText("");
        PasswordTxt.setText("");
    }

}
