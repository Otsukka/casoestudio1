package org.example;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calculadora extends JFrame{
    private JTextField Numero1Txt;
    private JTextField Numero2Txt;
    private JButton SumaBtn;
    private JButton ACBtn;
    private JLabel TotalLbl;
    private JLabel ResultadoLbl;
    private JPanel MainPanel;

    public calculadora(){

        setContentPane(MainPanel);
        setTitle("Calculadora");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(200,200);
        setVisible(true);

        SumaBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double total = 0;

                try {
                    double numero1 = Double.parseDouble(Numero1Txt.getText().replace(",","."));
                    double numero2 = Double.parseDouble(Numero2Txt.getText().replace(",","."));

                    total = numero1 + numero2;

                    ResultadoLbl.setText(String.valueOf(total));
                } catch (NumberFormatException exception){
                    JOptionPane.showMessageDialog(null,"Por favor ingrese solo numeros");
                } catch (ArithmeticException exception){
                    JOptionPane.showMessageDialog(null,"Hay un error de aritmerica");
                } catch (Exception exception){
                    JOptionPane.showMessageDialog(null,"Ocurrio un error");
                }
            }
        });

        ACBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCalculadora();
            }
        });

    }

    public void limpiarCalculadora(){
        Numero1Txt.setText("");
        Numero2Txt.setText("");
        ResultadoLbl.setText("");
    }

}
