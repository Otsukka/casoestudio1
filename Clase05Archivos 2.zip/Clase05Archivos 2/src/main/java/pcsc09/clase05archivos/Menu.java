/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pcsc09.clase05archivos;
import javax.swing.JOptionPane;
/**
 *
 * @author deivert.guiltrichs
 */
public class Menu {
    private int opcion = 0;
    
    ControlArchivos controlArchivo = new ControlArchivos();
    
    public void mostrarMenu()
    {
        while(opcion != 5)
        {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null, "Menú Principal:\n"
                                        + "1 - Agregar\n"
                                        + "2 - Modificar\n"
                                        + "3 - Eliminar\n"
                                        + "4 - Buscar\n"
                                        + "5 - Salir\n"
                                        + "Digite una opción para continuar: "
            ));
            switch(opcion)
            {
                case 1:
                    controlArchivo.agregar();
                    break;
                case 2:
                    controlArchivo.modificarCliente();
                    break;
                case 3: 
                    controlArchivo.eliminar();
                    break;
                case 4:
                    controlArchivo.buscarCliente();
                    break;
                case 5:
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
