/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pcsc09.clase05archivos;

/**
 *
 * @author deivert.guiltrichs
 */
public class Clase05Archivos {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.mostrarMenu();
    }
}
