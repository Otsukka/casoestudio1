/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pcsc09.clase05archivos;
import pcsc09.clase05archivos.pojos.Cliente;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
/**
 *
 * @author deivert.guiltrichs
 */
public class ControlArchivos {
    private static String cedula, nombre, email, telefono;
    
    public static boolean camposRequeridosIncompletos()
    {
        if((cedula.equals(""))
           || (nombre.equals(""))
           || (email.equals(""))
           || (telefono.equals("")))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public static void agregar()
    {
        try
        {
            //Aquí creamos el archivo y la entrada de datos
            DataOutputStream archivo = new DataOutputStream(new FileOutputStream("clientes.txt",true));
            //Aquí solicitamos los datos al usuario
            cedula = JOptionPane.showInputDialog("Digite su cédula:");
            nombre = JOptionPane.showInputDialog("Digite su nombre:");
            email = JOptionPane.showInputDialog("Digite su email:");
            telefono = JOptionPane.showInputDialog("Digite su telefono:");
            //Validamos que el usuario digitó toda la información requerida
            if(camposRequeridosIncompletos())
            {
                //Si nos faltó escribir algún dato, lanzamos un error, esto cae en el catch
                throw new Exception("Algunos de los campos requeridos no fueron completados");
            }
            else
            {
                //Si los datos están correctos escribimos en el archivo
                archivo.writeUTF(cedula);
                archivo.writeUTF(nombre);
                archivo.writeUTF(email);
                archivo.writeUTF(telefono);
                //Notificarle al usario que se guardaron los datos
                JOptionPane.showMessageDialog(null, "Datos guardados correctamente!", "Agregar Datos",
                        JOptionPane.INFORMATION_MESSAGE);
                //Debemos cerrar el archivo una vez que dejemos de utilizarlo
                archivo.close();
                
            }
        }
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al agregar los datos: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null, "Error al agregar los datos: " + e.getMessage(), "Error!",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public static void modificar()
    {
        String cedBusca, ced, nom, correo, tel;
        //boolean proximo = true;
        cedBusca = JOptionPane.showInputDialog("Digite la cédula de la persona a modificar: ");
        try
        {
            //Todo lo que debe salir bien, va en este try
            //En este try estamos generando los procesos de lectura y escritura de archivos
            //Definimos el archivo que queremos leer
            DataInputStream archivoLectura = new DataInputStream(new FileInputStream("clientes.txt"));
            //Definimos un archivo temporal, para almacenar los cambios del usuario, que se registrarán en el archivo original
            DataOutputStream archivoEscritura = new DataOutputStream(new FileOutputStream("temporal.txt"));
            
            //Vamos a hacer un try adicional que se va a encargar de buscar, recolectar la nueva información 
            // y modificar el archivo general
            try
            {
                while(true)
                {
                    //Descargamos el contenido del archivo
                    ced = archivoLectura.readUTF();
                    nom = archivoLectura.readUTF();
                    correo = archivoLectura.readUTF();
                    tel = archivoLectura.readUTF();
                    //Buscamos la cédula que digitó el usuario
                    if(cedBusca.equals(ced))
                    {
                        //Si la cédula existe entonces vamos a modificar el dato en el archivo
                        //Solicitamos los nuevos datos al usuario
                        nom = JOptionPane.showInputDialog("Digite el nuevo nombre:");
                        correo = JOptionPane.showInputDialog("Digite el nuevo correo:");
                        tel = JOptionPane.showInputDialog("Digite el nuevo teléfono:");
                    }
                    archivoEscritura.writeUTF(ced);
                    archivoEscritura.writeUTF(nom);
                    archivoEscritura.writeUTF(correo);
                    archivoEscritura.writeUTF(tel);
                }
            }
            catch(EOFException e)
            {
                archivoEscritura.close();
                archivoLectura.close();
                //En el momento en que alcancemos el final del archivo, vamos a intercambiar los datos del archivo 
                // temporal al archivo original
                intercambiar();
            }
        }
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al localizar el archivo: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        catch(IOException e)
        {
            //Todo lo que puede salir mal, va en este catch
            JOptionPane.showMessageDialog(null, "Los archivos tienen errores de lectura/escritura: " + e.getMessage(), "Error!", 
        JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public static void intercambiar()
    {
        String ced, nom, correo, tel;
        try
        {
            DataInputStream archivoLectura = new DataInputStream(new FileInputStream("temporal.txt"));
            DataOutputStream archivoEscritura = new DataOutputStream(new FileOutputStream("clientes.txt"));
            
            try
            {
                while(true)
                {
                    ced = archivoLectura.readUTF();
                    nom = archivoLectura.readUTF();
                    correo = archivoLectura.readUTF();
                    tel = archivoLectura.readUTF();
                    archivoEscritura.writeUTF(ced);
                    archivoEscritura.writeUTF(nom);
                    archivoEscritura.writeUTF(correo);
                    archivoEscritura.writeUTF(tel);
                }
            }
            catch(EOFException e)
            {
                archivoEscritura.close();
                archivoLectura.close();
            }
        }
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al localizar el archivo: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        catch(IOException e)
        {
            //Todo lo que puede salir mal, va en este catch
            JOptionPane.showMessageDialog(null, "Los archivos tienen errores de lectura/escritura: " + e.getMessage(), "Error!", 
        JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    public static void buscar()
    {
        String nomBusca, ced, nom, correo, tel;
        boolean proximo = true;
        nomBusca = JOptionPane.showInputDialog("Digite el nombre a buscar:");
        try
        {
            DataInputStream archivoLectura = new DataInputStream(new FileInputStream("clientes.txt"));
            try
            {
                while(proximo)
                {
                    ced = archivoLectura.readUTF();
                    nom = archivoLectura.readUTF();
                    correo = archivoLectura.readUTF();
                    tel = archivoLectura.readUTF();
                    if(nomBusca.equals(nom))
                    {
                        JOptionPane.showMessageDialog(null, "Se encontró a la persona: " + nom
                                            + ", cuya cédula es: " + ced + ", su correo es: " + correo 
                                            + " y su teléfono es: " + tel + ".");
                        proximo = false;
                    }
                }
            }
            catch(EOFException e)
            {
                cerrarArchivoLectura(archivoLectura);
            }
        }
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al localizar el archivo: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        catch(IOException e)
        {
            //Todo lo que puede salir mal, va en este catch
            JOptionPane.showMessageDialog(null, "Los archivos tienen errores de lectura/escritura: " + e.getMessage(), "Error!", 
        JOptionPane.INFORMATION_MESSAGE);
        } finally {

        }
    }
    
    public static void eliminar()
    {
        String cedBusca, ced, nom, correo, tel;
        //boolean proximo = true;
        cedBusca = JOptionPane.showInputDialog("Digite la cédula de la persona a eliminar: ");
        try
        {
            //Todo lo que debe salir bien, va en este try
            //En este try estamos generando los procesos de lectura y escritura de archivos
            //Definimos el archivo que queremos leer
            DataInputStream archivoLectura = new DataInputStream(new FileInputStream("clientes.txt"));
            //Definimos un archivo temporal, para almacenar los cambios del usuario, que se registrarán en el archivo original
            DataOutputStream archivoEscritura = new DataOutputStream(new FileOutputStream("temporal.txt"));
            
            //Vamos a hacer un try adicional que se va a encargar de buscar, recolectar la nueva información 
            // y modificar el archivo general
            try
            {
                while(true)
                {
                    //Descargamos el contenido del archivo
                    ced = archivoLectura.readUTF();
                    nom = archivoLectura.readUTF();
                    correo = archivoLectura.readUTF();
                    tel = archivoLectura.readUTF();
                    //Buscamos la cédula que digitó el usuario
                    if(!cedBusca.equals(ced))
                    {
                        //Si la cédula no es la que estamos buscando, mantenemos los datos en el archivo
                        archivoEscritura.writeUTF(ced);
                        archivoEscritura.writeUTF(nom);
                        archivoEscritura.writeUTF(correo);
                        archivoEscritura.writeUTF(tel);
                    }
                }
            }
            catch(EOFException e)
            {
                archivoEscritura.close();
                archivoLectura.close();
                //En el momento en que alcancemos el final del archivo, vamos a intercambiar los datos del archivo 
                // temporal al archivo original
                intercambiar();
            }
        }
        catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al localizar el archivo: " + e.getMessage(), "Error!", 
                    JOptionPane.INFORMATION_MESSAGE);
        }
        catch(IOException e)
        {
            //Todo lo que puede salir mal, va en este catch
            JOptionPane.showMessageDialog(null, "Los archivos tienen errores de lectura/escritura: " + e.getMessage(), "Error!", 
        JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void cerrarArchivoLectura(DataInputStream dataInputStream) throws IOException {
        dataInputStream.close();
    }

    public static void cerrarArchivoEscritura(DataOutputStream dataOutputStream) throws IOException {
        dataOutputStream.close();
    }

    public static List<Cliente> obtenerClientes(){

        List<Cliente> clientes = new ArrayList<>();

        try {

            DataInputStream dataInputStream = new DataInputStream(new FileInputStream("clientes.txt"));
            try {
                while (true){
                    Cliente cliente = new Cliente();

                    cliente.setCedula(dataInputStream.readUTF());
                    cliente.setNombre(dataInputStream.readUTF());
                    cliente.setEmail(dataInputStream.readUTF());
                    cliente.setTelefono(dataInputStream.readUTF());

                    clientes.add(cliente);
                }
            } catch (EOFException e){
                dataInputStream.close();
            }

        } catch (FileNotFoundException e){
            throw new RuntimeException(e);
        }catch (IOException e) {
            throw new RuntimeException(e);
        } catch (Exception e){
            throw new RuntimeException(e);
        }
        return clientes;
    }


    public static void buscarCliente()
    {
        String nomBusca, ced, nom, correo, tel;
        nomBusca = JOptionPane.showInputDialog("Digite el nombre a buscar:");
        try {
            List<Cliente> clientes = obtenerClientes();

            for(Cliente cliente : clientes){
                if(cliente.getNombre().equals(nomBusca)){
                    JOptionPane.showMessageDialog(null, "Se encontró a la persona: " + cliente.getNombre()
                            + ", cuya cédula es: " + cliente.getCedula() + ", su correo es: " + cliente.getEmail()
                            + " y su teléfono es: " + cliente.getTelefono() + ".");
                }
            }

        } catch(Exception e){

        }
    }

    public static void modificarCliente()
    {
        String cedBusca, ced, nom, correo, tel;
        //boolean proximo = true;
        cedBusca = JOptionPane.showInputDialog("Digite la cédula de la persona a modificar: ");
        try {

            List<Cliente> clientes = obtenerClientes();
            DataOutputStream archivoEscritura = new DataOutputStream(new FileOutputStream("temporal.txt"));

            for(Cliente cliente : clientes){
                if(cliente.getCedula().equals(cedBusca)){
                    nom = JOptionPane.showInputDialog("Digite el nuevo nombre:");
                    correo = JOptionPane.showInputDialog("Digite el nuevo correo:");
                    tel = JOptionPane.showInputDialog("Digite el nuevo teléfono:");
                    cliente.setNombre(nom);
                    cliente.setEmail(correo);
                    cliente.setTelefono(tel);
                }
                archivoEscritura.writeUTF(cliente.getCedula());
                archivoEscritura.writeUTF(cliente.getNombre());
                archivoEscritura.writeUTF(cliente.getEmail());
                archivoEscritura.writeUTF(cliente.getTelefono());
            }

            intercambiar();

        }catch(FileNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Error al localizar el archivo: " + e.getMessage(), "Error!",
                    JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


}
