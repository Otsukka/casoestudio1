/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pcsc4.sem4procesadorexcepciones;

import java.util.Scanner;

/**
 *
 * @author deiv
 */
public class Sem4ProcesadorExcepciones {

    public static void main(String[] args) {
        Rutinas r = new Rutinas();

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("Ingrese el primer valor");
            String primero = scanner.nextLine();
            System.out.println("Ingrese el segundo valor");
            String segundo = scanner.nextLine();
            r.dividirNumeros(Double.parseDouble(primero), Double.parseDouble(segundo));
        }catch (NumberFormatException error){
            System.out.println("Favor ingresar solo valores numericos");
        } catch (Exception e){
            System.out.println("Error");
        }


        r.dividirNumeros(6.0, null);
        r.dividirNumeros(6.0, 3.0);
        r.dividirNumeros(9.0, 0.0);
    }
}
