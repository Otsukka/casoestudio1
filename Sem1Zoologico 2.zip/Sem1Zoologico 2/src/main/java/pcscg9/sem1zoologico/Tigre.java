/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pcscg9.sem1zoologico;

/**
 *
 * @author deiv
 */
//1. Declaración de la clase
public class Tigre extends Felino implements Carnivoro {
    //Vamos a trabajar en la forma del objeto
    //2. Declaración de atributos
    //Aquí vamos a tener el mismo método para dormir --- PRIVADO
    String nombre;
    String tipoTigre;
    boolean estaDurmiendo;
    boolean estaComiendo;
    final String caracteristicaPrincipal = "Rayado";
    
    //Vamos a trabajar en el comportamiento del objeto
    //3. Declaración de métodos
    
    //4. Declaración de comentarios: En el constructor se determina el nombre del tigre
    public Tigre(String nombre) {
        this.nombre = nombre; //Seteando o asignando el nombre del tigre, por lo tanto ya no necesitamos el set del tigre
                              //aunque podríamos implementarlo si el nombre es una característica cambiante en el objeto
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoTigre() {
        return tipoTigre;
    }

    public void setTipoTigre(String tipoTigre) {
        this.tipoTigre = tipoTigre;
    }

    public boolean isEstaDurmiendo() {
        return estaDurmiendo;
    }

    public void setEstaDurmiendo(boolean estaDurmiendo) {
        this.estaDurmiendo = estaDurmiendo;
    }

    public boolean isEstaComiendo() {
        return estaComiendo;
    }

    public void setEstaComiendo(boolean estaComiendo) {
        this.estaComiendo = estaComiendo;
    }
    
    public void determinarActividadDelTigre()
    {
        //Si el tigre está comiendo
        
        //O si el tigre está durmiendo
        
        //O si el tigre no está haciendo nada
    }
    
    private void identificarHabitatTigre()
    {
        System.out.println("El tigre asiático vive en zonas pantanosas");
    }
    
    public void presentarTigre()
    {
        System.out.println("Este tigre se llama: " + this.getNombre());
        System.out.println("Este tigre es de tipo: " + this.getTipoTigre());
        this.identificarHabitatTigre();
    }
    
    public static void existenTigres()
    {
        System.out.println("Sí, en el zoologico tenemos tigres");
    }
    
    
    //Sobrecarga de métodos
    public void definirEncargadoTigre(String nombreEncargado)
    {
        System.out.println("El encargado del tigre es: " + nombreEncargado);
    }
    
    public void definirEncargadoTigre(int idEncargado)
    {
        System.out.println("El encargado del tigre tiene el identificador: " + idEncargado);
    }
    
        public void comerCarne()
    {
        System.out.println("El tigre está comiendo carne");
    }
    
    public void digerirCarne()
    {
        System.out.println("El tigre tarda alrededor de dos horas en digerir la carne que consume");
    }
}
