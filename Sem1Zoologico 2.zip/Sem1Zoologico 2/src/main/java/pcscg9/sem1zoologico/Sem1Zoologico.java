/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package pcscg9.sem1zoologico;

import java.util.*;

/**
 *
 * @author deiv
 */
public class Sem1Zoologico {

    public static void main(String[] args) {
        //Vamos a construir un objeto de tipo Tigre
        
        System.out.println("*TIGRES DEL ZOOLOGICO*");
        
        //Esta es una instancia de Tigre, que nos genera un objeto de ese tipo
                        //Llamada al constructor
        Tigre unTigre = new Tigre("Tony"); //Este tigre está almacenado en el espacio de memoria A
        
        //Vamos a crear otro objeto de tipo Tigre
        
        Tigre otroTigre = new Tigre("Lorenzo"); //Este tigre está almacenado en el espacio de memoria B
        
        Tigre tercerTigre = new Tigre("Toby"); //Este tigre está almacenado en el espacio de memoria C
        
        tercerTigre = otroTigre; //Liberamos el espacio de memoria C y tanto tercerTigre como otroTigre apuntan al espacio
                                 // de memoria B
                                
        Tigre.existenTigres();
        System.out.println("Este es un espacio de memoria: " + unTigre);
        System.out.println("Hola soy un tigre y me llamo: " + unTigre.getNombre());
        System.out.println("Hola soy otro tigre y me llamo: " + otroTigre.getNombre());
        
        System.out.println("* EJEMPLO DE HERENCIA, POLIMORFISMO Y COLECCIONES *");
        
        Animal[] animalesZoo = new Animal[3];
        
        //POLIMORFISMO
        animalesZoo[0] = unTigre;
        animalesZoo[1] = new Cocodrilo();
        animalesZoo[2] = new TigrePigmeo("Peque", 25);
        
        for(int i = 0; i < animalesZoo.length; i++)
        {
            if(animalesZoo[i] instanceof Reptil)
            {
                System.out.println("Encontramos un reptil");
            }
        }
        
        Mamifero[] mamiferos = new Mamifero[3];
        
        mamiferos[0] = new Felino();
        mamiferos[1] = otroTigre;
        //mamiferos[2] = animalesZoo[2];

        Set zooSet = new HashSet();
        zooSet.add("prueba");
        zooSet.add(20.0);
        zooSet.add(20.0f);
        zooSet.add(unTigre);
        zooSet.add(20.0);
        zooSet.add("prueba");
        zooSet.add(new Tigre("Julio"));
        zooSet.add(unTigre);

        for(Object o : zooSet){
            if(o instanceof Tigre){
                Tigre tigre = (Tigre) o;
                tigre.getNombre();
            } else if (o instanceof  String) {
                System.out.println((String) o);
            }
        }

        Set<Tigre> tigreSet = new HashSet<>();
        tigreSet.add(unTigre);
        tigreSet.add(new Tigre("Julio"));
        tigreSet.add(new Tigre("Zucaritas"));
        tigreSet.add(unTigre);
        tigreSet.add(otroTigre);

        for(Tigre tigre : tigreSet){
            System.out.println(tigre.getNombre());
        }

        List zooList = new ArrayList();
        zooList.add(otroTigre);
        zooList.add(otroTigre);
        zooList.add(20);
        zooList.add(65L);
        zooList.add(20);
        zooList.add("Lista");

        zooList.add(2,"prueba");

        List<Tigre> tigreList = new ArrayList<>();
        tigreList.add(unTigre);
        tigreList.add(new Tigre("Julio"));
        tigreList.add(new Tigre("Zucaritas"));
        tigreList.add(unTigre);
        tigreList.add(otroTigre);

        for(Tigre tigre : tigreList){
            System.out.println("tigre lista "+tigre.getNombre());
        }

        for (Object o : zooList){
            if(o instanceof Tigre){
                Tigre tigre = (Tigre) o;
                System.out.println(o);
            } else if(o instanceof  String){
                String msg = (String) o;
                System.out.println(msg);
            }
        }

        System.out.println("");

        Map<String, Tigre> tigreMap = new HashMap<>();
        tigreMap.put("PRIMERO",otroTigre);
        tigreMap.put("TERCERO",unTigre);
        tigreMap.put("DECIMO",tercerTigre);
        tigreMap.put("SETIMO",new Tigre("Julio"));
        tigreMap.put("QUINTO",new Tigre("Zucaritas"));

        System.out.println(tigreMap.get("SETIMO").getNombre());

        for(Map.Entry<String, Tigre> entry : tigreMap.entrySet()){
            System.out.println(String.format("la clave es: %s, el valor es: %s",entry.getKey(),entry.getValue().getNombre()));
        }

        
    }
}
