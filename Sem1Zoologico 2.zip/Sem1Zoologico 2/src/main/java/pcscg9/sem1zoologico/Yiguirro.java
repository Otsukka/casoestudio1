/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pcscg9.sem1zoologico;

/**
 *
 * @author deiv
 */
public class Yiguirro extends AveVoladora {
    public void volar()
    {
        System.out.println("El yiguirro vuela gracias a sus características físicas de cuerpo alargado");
    }
}
